# Curriculum Mapping Agent — Reference Implementation v0.1

## Purpose
This agent reads raw HSC Biology question batches, maps each question to the
shared HSC Biology taxonomy, and persistently stacks the resulting records in
one `data/master/question.json` file.

## Important design rules
1. Raw questions are never overwritten.
2. The master taxonomy is read-only to the agent.
3. The agent never invents taxonomy IDs.
4. No answer is required or generated at this stage.
5. Duplicate detection happens before an LLM call.
6. High-confidence mappings are marked `auto_accepted`; low-confidence mappings
   remain in the same master file with `human_review_required`.
7. `taxonomy_update_required` is used when no concept candidate is adequate.
8. The question store is written atomically and backed up.

## Setup
Create and activate a Python environment, then:

```bash
pip install -r requirements.txt
```

Set environment variables from `.env.example` in your shell/environment:

- `LLM_ENDPOINT`
- `LLM_API_KEY`
- `LLM_MODEL`

The included `src/llm_client.py` expects a chat-completions-compatible HTTP
endpoint. If your model provider uses a different API format, replace only that
adapter.

## Run
From the project root:

```bash
python -m src.main --input data/incoming/barishal_2025_raw_input_batch_01.json
```

Then later:

```bash
python -m src.main --input data/incoming/barishal_2025_raw_input_batch_02.json
python -m src.main --input data/incoming/barishal_2025_raw_input_batch_03.json
```

All accepted/new records stack into the same:
`data/master/question.json`.

## Test
```bash
pytest -q
```

## Confidence warning
The v0.1 confidence is the minimum of the four LLM-reported stage confidences.
It is useful for routing, but it is NOT yet calibrated. Manually review a pilot
sample and tune `auto_accept_threshold` before relying on automatic acceptance.
