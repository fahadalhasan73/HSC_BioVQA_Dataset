import re
from difflib import SequenceMatcher
from typing import Any

from .normalizer import normalize_text
from .taxonomy_loader import TaxonomyIndex


_TOKEN_RE = re.compile(r"\w+", flags=re.UNICODE)


def _tokens(text: str) -> set[str]:
    return set(_TOKEN_RE.findall(normalize_text(text).lower()))


def _score(query: str, document: str) -> float:
    q = normalize_text(query).lower()
    d = normalize_text(document).lower()
    if not q or not d:
        return 0.0

    q_tokens = _tokens(q)
    d_tokens = _tokens(d)

    overlap = 0.0
    if q_tokens:
        overlap = len(q_tokens & d_tokens) / len(q_tokens)

    sequence = SequenceMatcher(None, q, d).ratio()

    substring_boost = 0.0
    for token in q_tokens:
        if len(token) >= 4 and token in d:
            substring_boost += 1.0
    substring_boost = min(substring_boost / max(len(q_tokens), 1), 1.0)

    return round(0.50 * overlap + 0.35 * sequence + 0.15 * substring_boost, 6)


class CandidateRetriever:
    def __init__(self, taxonomy: TaxonomyIndex):
        self.taxonomy = taxonomy

    def rank(
        self,
        query: str,
        candidates: list[dict[str, Any]],
        top_k: int,
    ) -> list[dict[str, Any]]:
        scored = []
        for node in candidates:
            score = _score(query, self.taxonomy.candidate_document(node["id"]))
            scored.append({**node, "_retrieval_score": score})

        scored.sort(key=lambda x: x["_retrieval_score"], reverse=True)

        # If the candidate set is already small, keep all of it. This avoids
        # accidentally pruning the correct curriculum label in v0.1.
        if len(scored) <= top_k:
            return scored

        return scored[:top_k]
