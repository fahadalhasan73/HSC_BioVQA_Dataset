import json
import os
import time
from typing import Any

from google import genai
from google.genai import types


class LLMError(RuntimeError):
    pass


class LLMClient:

    def __init__(
        self,
        api_key: str,
        model: str,
        max_retries: int = 3,
        temperature: float = 0.0,
    ):
        self.api_key = api_key
        self.model = model
        self.max_retries = max_retries
        self.temperature = temperature

        self.client = genai.Client(
            api_key=api_key
        )

    @classmethod
    def from_config(
        cls,
        llm_config: dict[str, Any]
    ) -> "LLMClient":

        api_key_env = llm_config.get(
            "api_key_env",
            "GEMINI_API_KEY"
        )

        model_env = llm_config.get(
            "model_env",
            "GEMINI_MODEL"
        )

        api_key = os.environ.get(
            api_key_env,
            ""
        ).strip()

        model = os.environ.get(
            model_env,
            ""
        ).strip()

        missing = []

        if not api_key:
            missing.append(api_key_env)

        if not model:
            missing.append(model_env)

        if missing:
            raise LLMError(
                "Missing required environment variable(s): "
                + ", ".join(missing)
            )

        return cls(
            api_key=api_key,
            model=model,
            max_retries=int(
                llm_config.get(
                    "max_retries",
                    3
                )
            ),
            temperature=float(
                llm_config.get(
                    "temperature",
                    0.0
                )
            ),
        )

    def classify_json(
        self,
        prompt: str
    ) -> dict[str, Any]:

        last_error = None

        for attempt in range(
            1,
            self.max_retries + 1
        ):

            try:

                response = (
                    self.client.models.generate_content(
                        model=self.model,
                        contents=prompt,
                        config=types.GenerateContentConfig(
                            temperature=self.temperature,
                            response_mime_type=
                                "application/json",
                        ),
                    )
                )

                text = (
                    response.text or ""
                ).strip()

                if not text:
                    raise LLMError(
                        "Gemini returned an empty response."
                    )

                parsed = json.loads(text)

                if not isinstance(
                    parsed,
                    dict
                ):
                    raise LLMError(
                        "Gemini returned JSON, "
                        "but it was not a JSON object."
                    )

                return parsed

            except Exception as exc:

                last_error = exc

                if attempt < self.max_retries:

                    time.sleep(
                        min(
                            2 ** (attempt - 1),
                            8
                        )
                    )

        raise LLMError(
            "Gemini request failed after "
            f"{self.max_retries} attempts: "
            f"{last_error}"
        )